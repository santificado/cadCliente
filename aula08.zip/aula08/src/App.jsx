import Etiquetas from "./components/Etiquetas"


export default function App(){

    return(
        <>
            <h1>Aula08</h1>
            <Etiquetas />
        </>
    )
}